<?php
/*
Plugin Name: My Collection Plugin
Description: Provides endpoints for token generation, validation, and user retrieval.
Version: 1.0
Author: Your Name
*/

// Include TokenManager class
require_once(plugin_dir_path(__FILE__) . 'TokenManager.php');

// Register endpoints
add_action('rest_api_init', function() {
    register_rest_route('wfactor/v1', '/token', array(
        'methods' => 'POST',
        'callback' => 'wfactor_generate_token',
    ));

    register_rest_route('wfactor/v1', '/validate', array(
        'methods' => 'POST',
        'callback' => 'wfactor_validate_token',
    ));

    register_rest_route('wfactor/v1', '/user', array(
        'methods' => 'POST',
        'callback' => 'wfactor_get_user',
    ));
});

// Token generation endpoint callback
function wfactor_generate_token($request) {
    $username = $request->get_param('username');
    $password = $request->get_param('password');

    $token = TokenManager::generateToken($username, $password);

    return array(
        'token' => $token,
    );
}

// Token validation endpoint callback
function wfactor_validate_token($request) {
    $token = $request->get_param('token');

    $is_valid = TokenManager::validateToken($token);

    return array(
        'valid' => $is_valid,
    );
}

// User retrieval endpoint callback
function wfactor_get_user($request) {
    $token = $request->get_param('token');

    $user = TokenManager::getUserFromToken($token);

    if ($user) {
        $username = $user->user_login;
        $email = $user->user_email;

        return array(
            'username' => $username,
            'email' => $email,
        );
    }

    return null;
}